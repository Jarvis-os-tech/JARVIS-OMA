"""CLI entry point: python -m jarvis_voice"""
import argparse
import importlib.util
import os
import shutil
import subprocess
import sys


def _systemd_command(action: str) -> int:
    """Manage the universal-voice systemd user service."""
    service = 'universal-voice.service'
    if action == 'restart':
        print('Restarting JARVIS...')
        rc = subprocess.call(['systemctl', '--user', 'restart', service])
        if rc == 0:
            print('JARVIS is active and running.')
        return rc
    elif action in ('disable', 'disanble'):
        print('Disabling JARVIS service...')
        rc = subprocess.call(['systemctl', '--user', 'disable', '--now', service])
        if rc == 0:
            print('JARVIS service disabled and stopped.')
        return rc
    elif action == 'enable':
        print('Enabling JARVIS service...')
        rc = subprocess.call(['systemctl', '--user', 'enable', '--now', service])
        if rc == 0:
            print('JARVIS service enabled and active.')
        return rc
    elif action == 'start':
        print('Starting JARVIS...')
        return subprocess.call(['systemctl', '--user', 'start', service])
    elif action == 'stop':
        print('Stopping JARVIS...')
        return subprocess.call(['systemctl', '--user', 'stop', service])
    return 1


def _ipc_command(args):
    """Send a command to the running daemon via its control socket."""
    import socket
    from .config import SOCKET_PATH

    if not SOCKET_PATH.exists():
        print('universal-voice is not running', file=sys.stderr)
        return 1

    if args.command == 'status':
        cmd = 'status --json' if args.json else 'status'
    elif args.command == 'listen':
        action = args.action or 'toggle'
        cmd = f'listen {action}'
    elif args.command == 'standby':
        cmd = 'wake' if args.action == 'off' else 'standby toggle' if args.action == 'toggle' else 'standby'
    elif args.command == 'wake':
        cmd = 'wake'
    elif args.command in ('send', 'tell', 'prompt'):
        text = ' '.join(([args.action] if args.action else []) + (getattr(args, 'text_args', None) or [])).strip()
        if not text:
            print('send requires a text message to send to JARVIS', file=sys.stderr)
            return 1
        cmd = f'send {text}'
    else:
        cmd = args.command

    try:
        sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        sock.settimeout(3)
        sock.connect(str(SOCKET_PATH))
        sock.sendall((cmd + '\n').encode())
        data = sock.recv(4096)
        sock.close()
        print(data.decode().strip())
        return 0
    except Exception as e:
        print(f'IPC error: {e}', file=sys.stderr)
        return 1


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog='universal-voice',
        description='JARVIS Voice Core — sovereign voice foundation')
    parser.add_argument('command', nargs='?', default='run',
        choices=['run', 'status', 'listen', 'standby', 'wake', 'send', 'tell', 'prompt', 'restart', 'disable', 'disanble', 'enable', 'start', 'stop'],
        help='Command to execute (default: run)')
    parser.add_argument('action', nargs='?', help='Action for listen or first word for send')
    parser.add_argument('text_args', nargs='*', help='Additional words for send/tell')
    parser.add_argument('--model', default=os.getenv('GEMINI_LIVE_MODEL'))
    parser.add_argument('--voice', default=None, help='Gemini voice name')
    parser.add_argument('--check', action='store_true',
        help='Check dependencies without opening audio or network')
    parser.add_argument('--json', action='store_true', help='Output JSON')
    parser.add_argument('--transcripts', action='store_true')
    parser.add_argument('--retries', type=int, default=5)

    args = parser.parse_args(argv)
    if args.command == 'listen' and args.action not in (None, 'toggle', 'start', 'stop', 'cancel', 'confirm', 'standby'):
        parser.error('listen action must be toggle, start, stop, cancel, confirm or standby')
    if args.retries < 0:
        parser.error('retries must be zero or a positive integer')

    if args.check:
        from .doctor import check
        return check()

    if args.command in ('restart', 'disable', 'disanble', 'enable', 'start', 'stop'):
        return _systemd_command(args.command)

    if args.command in ('status', 'listen', 'standby', 'wake', 'send', 'tell', 'prompt'):
        return _ipc_command(args)

    if args.command == 'run':
        try:
            from .daemon import main as daemon_main
            return daemon_main(args)
        except ImportError as error:
            print(f'Voice dependency unavailable: {error}', file=sys.stderr)
            return 1

    return 0


if __name__ == '__main__':
    raise SystemExit(main())
