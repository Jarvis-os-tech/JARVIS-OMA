"""Bounded PCM playback with generation fences for interruption races.

Fix 6: Stale-generation chunks are silently discarded, never triggering
PlaybackBacklogError from cancelled generations.
"""
import asyncio
import contextlib
import struct
import time

from .speech import PlaybackReference

PLAYBACK_LATENCY = '80ms'
PLAYBACK_LEAD_SECONDS = .12
PRIME_BYTES = 3840  # 80 ms of 24 kHz mono PCM16
PRIME_WAIT_SECONDS = .04  # Bound startup delay without reducing the device buffer

OUTPUT_BYTES = 960  # 20 ms at 24 kHz mono PCM16
PLAYBACK_MAX_BYTES = 48000 * 60  # 60 seconds


class MicrophoneBacklogError(BufferError):
    """Active microphone traffic cannot advance through the transport."""


class PlaybackBacklogError(BufferError):
    """The provider exceeded the bounded playback backlog."""


async def stop_process(process):
    """Terminate an owned audio process, escalating only if it will not exit."""
    if process is None:
        return
    if process.returncode is None:
        with contextlib.suppress(ProcessLookupError):
            process.terminate()
    if process.stdin is not None:
        process.stdin.close()
    try:
        await asyncio.wait_for(process.wait(), 1)
    except TimeoutError:
        with contextlib.suppress(ProcessLookupError):
            process.kill()
        await process.wait()


def audio_environment():
    """Subprocess environment with PipeWire overrides removed."""
    import os
    env = dict(os.environ)
    for name in ('PIPEWIRE_LATENCY', 'PIPEWIRE_QUANTUM', 'PIPEWIRE_NODE',
                 'PULSE_SOURCE', 'PULSE_SINK'):
        env.pop(name, None)
    return env


class Playback:
    """Bounded PCM playback with generation fences for interruption races."""

    def __init__(self, sink):
        self.sink = sink
        self.queue = asyncio.Queue(maxsize=6000)
        self.queued_bytes = 0
        self._queued_filler_frames = 0
        self.generation = 0
        self._epoch = 0
        self.process = None
        self.playback_until = 0.0
        self._writing = False
        self._writing_generation = 0
        self._writing_epoch = 0
        self.reference = PlaybackReference()
        self._spawn_lock = asyncio.Lock()
        self.first_write_at = None
        self.first_enqueued_at = None
        self.first_chunk_write_ms = None
        self._arrival = asyncio.Event()
        self.reply_complete = False

    def is_playing(self, tail: float = 0.0) -> bool:
        return ((self._writing and self._writing_generation == self.generation
                 and self._writing_epoch == self._epoch)
                or not self.queue.empty() or time.monotonic() < self.playback_until + tail)

    @property
    def busy(self):
        return self.is_playing(0.0)

    def enqueue(self, data):
        if len(data) % 2:
            raise ValueError('Gemini output contains an incomplete PCM16 sample')
        chunks = (len(data) + OUTPUT_BYTES - 1) // OUTPUT_BYTES
        if (chunks > self.queue.maxsize - self.queue.qsize()
                or self.queued_bytes + len(data) > PLAYBACK_MAX_BYTES):
            raise PlaybackBacklogError('Provider audio exceeded bounded playback backlog')
        if data and self.first_enqueued_at is None:
            self.first_enqueued_at = time.monotonic()
        for offset in range(0, len(data), OUTPUT_BYTES):
            chunk = data[offset:offset + OUTPUT_BYTES]
            self.queue.put_nowait((self.generation, chunk))
            self.queued_bytes += len(chunk)
        self._arrival.set()

    def enqueue_filler(self, data):
        empty = self.queue.empty()
        self.enqueue(data)
        if empty:
            self._queued_filler_frames = (len(data) + OUTPUT_BYTES - 1) // OUTPUT_BYTES

    def enqueue_response(self, data):
        """Let the real answer replace queued filler with a 20 ms transition."""
        if len(data) % 2:
            raise ValueError('Gemini output contains an incomplete PCM16 sample')
        if not data:
            return
        transition = None
        while self._queued_filler_frames and not self.queue.empty():
            generation, chunk = self.queue.get_nowait()
            self.queued_bytes -= len(chunk)
            self._queued_filler_frames -= 1
            if transition is None and generation == self.generation:
                transition = chunk
        self._queued_filler_frames = 0
        if transition:
            mixed = bytearray(data)
            count = min(len(transition), len(data), OUTPUT_BYTES) // 2
            for i in range(count):
                weight = (i + 1) / count
                old = struct.unpack_from('<h', transition, i * 2)[0]
                new = struct.unpack_from('<h', data, i * 2)[0]
                struct.pack_into('<h', mixed, i * 2, round(old * (1 - weight) + new * weight))
            data = bytes(mixed)
        self.enqueue(data)

    def cancel_pending(self, *, preserve_generation=False):
        """Flush queued audio and fence in-flight writes, returning the old process."""
        self._epoch += 1
        if not preserve_generation:
            self.generation += 1
        self.playback_until = 0.0
        self.begin_reply()
        while not self.queue.empty():
            self.queue.get_nowait()
        self.queued_bytes = 0
        self._queued_filler_frames = 0
        self._arrival.set()
        process, self.process = self.process, None
        return process

    def begin_reply(self):
        self.first_enqueued_at = self.first_write_at = self.first_chunk_write_ms = None
        self.reply_complete = False

    def finish_reply(self):
        self.reply_complete = True
        self._arrival.set()

    async def _prime(self, generation, epoch, first_bytes):
        """Absorb short provider gaps without waiting for an entire response."""
        deadline = time.monotonic() + PRIME_WAIT_SECONDS
        while (generation == self.generation and epoch == self._epoch and not self.reply_complete
               and first_bytes + self.queued_bytes < PRIME_BYTES):
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                break
            self._arrival.clear()
            try:
                await asyncio.wait_for(self._arrival.wait(), remaining)
            except TimeoutError:
                break
        return generation == self.generation and epoch == self._epoch

    async def interrupt(self):
        process = self.cancel_pending()
        await stop_process(process)

    async def prepare(self, generation=None, epoch=None):
        """Open playback subprocess before first chunk to avoid startup latency."""
        generation = self.generation if generation is None else generation
        epoch = self._epoch if epoch is None else epoch
        async with self._spawn_lock:
            if generation != self.generation or epoch != self._epoch:
                return False
            if self.process is None:
                process = await asyncio.create_subprocess_exec(
                    'pw-play', '--rate', '24000', '--channels', '1', '--format', 's16',
                    '--latency', PLAYBACK_LATENCY, '--target', self.sink, '-a', '-',
                    stdin=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
                    env=audio_environment())
                if generation != self.generation or epoch != self._epoch:
                    await stop_process(process)
                    return False
                self.process = process
            return generation == self.generation and epoch == self._epoch

    async def run(self):
        """Main playback loop — Fix 6: stale generations silently discarded."""
        while True:
            generation, data = await self.queue.get()
            epoch = self._epoch
            self.queued_bytes -= len(data)
            if self._queued_filler_frames:
                self._queued_filler_frames -= 1

            # Fix 6: silently discard chunks from cancelled generations
            if generation != self.generation or epoch != self._epoch:
                continue

            self._writing = True
            self._writing_generation = generation
            self._writing_epoch = epoch
            try:
                if self.first_write_at is None and not await self._prime(generation, epoch, len(data)):
                    continue
                if not await self.prepare(generation, epoch) or generation != self.generation or epoch != self._epoch:
                    continue
                process = self.process
                if process.returncode is not None:
                    raise RuntimeError(f'Audio output process exited (code={process.returncode})')
                try:
                    process.stdin.write(data)
                    self.reference.add(data)
                    await asyncio.wait_for(process.stdin.drain(), 2)
                except TimeoutError as error:
                    # Fix 6: check generation before raising
                    if generation != self.generation or epoch != self._epoch:
                        continue
                    raise PlaybackBacklogError('PipeWire playback stopped accepting PCM') from error
                except (BrokenPipeError, ConnectionResetError):
                    if generation != self.generation or epoch != self._epoch:
                        continue
                    raise
                if generation != self.generation or epoch != self._epoch:
                    continue
                now = time.monotonic()
                if self.first_write_at is None and self.first_enqueued_at is not None:
                    self.first_write_at = now
                    self.first_chunk_write_ms = round((now - self.first_enqueued_at) * 1000)
                self.playback_until = max(self.playback_until, now) + len(data) / 48000
            finally:
                self._writing = False
            await asyncio.sleep(max(0.0, self.playback_until - time.monotonic() - PLAYBACK_LEAD_SECONDS))
